# setup ufw
```
sudo ufw allow ssh
sudo ufw default deny incoming
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
sudo ufw status verbose
```

# run
```
$ docker-compose up -d
```

# elasticsearch provisioning

**create esu-metrics index (prehaps automated in the future)**
```
# check network for elasticsearch-container-ip
$ docker network inspect server-setup_default


## elasticsearch < 7
$ curl -X PUT "127.0.0.1:9200/esu-metrics" -H 'Content-Type: application/json' -d'
{
  "esu-metrics" : {
    "mappings" : {
      "esu" : {
        "properties" : {
          "avg_act_curr" : {
            "type" : "float"
          },
          "avg_ext_volt" : {
            "type" : "float"
          },
          "avg_soc" : {
            "type" : "integer"
          },
          "avg_soh" : {
            "type" : "long"
          },
          "avg_temp" : {
            "type" : "integer"
          },
          "avg_watts" : {
            "type" : "float"
          },
          "datetime" : {
            "type" : "date",
            "format" : "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.SSS"
          },
          "hostname" : {
            "type" : "text",
            "fields" : {
              "keyword" : {
                "type" : "keyword",
                "ignore_above" : 10
              }
            }
          },
          "location" : {
            "type" : "geo_point"
          },
          "num_etas" : {
            "type" : "integer"
          },
          "num_tubes" : {
            "type" : "integer"
          }
        }
      }
    }
  }
}
'

## elasticsearch 7.8

curl -X PUT "127.0.0.1:9200/esu-metrics?pretty" -H 'Content-Type: application/json' -d'
{
  "settings": {
    "number_of_shards": 10
  },
  "mappings": {
    "properties": {
      "datetime": {
        "type": "date",
        "format": "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd HH:mm:ss.SSS"
      },
      "hostname": {
        "type": "text",
        "fields": {
          "keyword": {
            "type": "keyword",
            "ignore_above": 10
          }
        }
      },
      "avg_act_curr": {
        "type": "float"
      },
      "avg_ext_volt": {
        "type": "float"
      },
      "avg_soc": {
        "type": "integer"
      },
      "avg_temp": {
        "type": "integer"
      },
      "avg_watts": {
        "type": "float"
      },
      "num_tubes": {
        "type": "integer"
      },
      "num_etas": {
        "type": "integer"
      },
      "location": {
        "type": "geo_point"
      }
    }
  }
}
'
```
